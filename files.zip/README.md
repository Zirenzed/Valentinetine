# 💕 Valentine's Day Website

A playful and romantic website to ask someone to be your Valentine! Features a fun heart-catching game and interactive Yes/No buttons.

## ✨ Features

- 🎮 Interactive heart-catching game with a cute cat character
- 💝 Romantic story introduction
- 🎯 Playful "No" button that runs away when clicked
- 🎉 Confetti celebration on "Yes"
- 📱 Fully optimized for iPhone and mobile devices

## 🚀 Deploy to GitHub Pages

### Quick Setup (5 minutes)

1. **Create a new GitHub repository**
   - Go to [github.com](https://github.com) and log in
   - Click the "+" icon in the top right → "New repository"
   - Name it whatever you want (e.g., `valentine-proposal`)
   - Make it Public
   - Click "Create repository"

2. **Upload the file**
   - On your new repository page, click "uploading an existing file"
   - Drag and drop the `index.html` file
   - Click "Commit changes"

3. **Enable GitHub Pages**
   - Go to your repository's "Settings" tab
   - Scroll down to "Pages" in the left sidebar
   - Under "Source", select "main" branch
   - Click "Save"

4. **Get your website URL**
   - Wait 1-2 minutes for deployment
   - Your site will be live at: `https://YOUR-USERNAME.github.io/REPO-NAME/`
   - Share this link with your special someone! 💕

## 🎨 Customization

You can edit the `index.html` file to customize:
- The romantic messages in the story section
- The number of hearts to catch (currently 10)
- The messages that appear when clicking "No"
- Colors and animations

## 💖 Good luck with your Valentine's proposal!

---

Made with ❤️ by you!
